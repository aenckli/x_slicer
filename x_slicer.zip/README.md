# laser_slicer
Laser slicer add-on for Blender 2.8.
The Laser Slicer cuts up a Blender object and exports the slices to SVG files for cutting on a laser cutter or other post-processing.
More details and link to tutorial video can be found at:
	https://blendscript.blogspot.com/2019/01/blender-28-laser-slicer.html

