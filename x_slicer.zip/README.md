# x_slicer
 X-Slicer for Blender
This addon slices an object in one or two directions for cutting. For two direction slices, interlocking slots are added for assembly.